<?php
require_once('db-connect.php');
function save_post(){
    global $conn;
    extract($_POST);

    $title = addslashes($conn->real_escape_string($title));
    $content = addslashes($conn->real_escape_string($content));

    if($is_draft){
        $id = (!empty($id) ? $id : 0);
        if(!empty($auto_id)){
            $sql = "UPDATE `posts` set `title` = '{$title}', `content` = '{$content}' where `id` = '{$auto_id}' ";
        }else{
            $sql = "INSERT INTO `posts` (`title`, `content`, `parent_id`, `status`) VALUES ('{$title}', '{$content}', '{$id}', 'draft')";
        }
    }else{
        if(!empty($id)){
            $sql = "UPDATE `posts` set `title` = '{$title}', `content` = '{$content}', `parent_id` = 0 where `id` = '{$id}' ";
        }else{
            $sql = "INSERT INTO `posts` (`title`, `content`, `parent_id`, `status`) VALUES ('{$title}', '{$content}', 0, 'publish')";
        }
    }

    $save = $conn->query($sql);
    $id = (!empty($id) && is_numeric($id) && $id > 0) ? $id : '';
    $auto_id = (!empty($auto_id) && is_numeric($auto_id) && $auto_id > 0) ? $auto_id : '';
    if($save){
        $response['status'] = 'success';
        if($is_draft){
            if(empty($auto_id)){
                $auto_id = $conn->insert_id;
            }
        }else{
            if(empty($id)){
                $id = $conn->insert_id;
            }
            if(!empty($id))
            $conn->query("DELETE FROM `posts` where `parent_id` = '{$id}' or id = '{$auto_id}' ");
        }
        $response['id'] = $id;
        $response['auto_id'] = $auto_id;
        $response['sql'] = $sql;
    }else{
        $response['status'] = 'failed';
        $response['error'] = $conn->error;
    }


    return json_encode($response);
}


$save_as = $_GET['save_as'];
if($save_as == 'draft'){
    $_POST['is_draft'] = true;
    $save = save_post();
}else{
    $_POST['is_draft'] = false;
    $save = save_post();
}
echo $save;
$conn->close();